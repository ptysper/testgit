rm -rf output_json output_csv >> /dev/null
mkdir output_json output_csv >> /dev/null
python3.7 parser.py
for file in output_json/*; do
    cat $file | jq . > $file.new
    rm $file && mv $file.new $file
done
