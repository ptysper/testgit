#!/bin/bash

# Run anisble playbook

function pause(){
	read -p "Press [Enter] key to start backup..."
}

echo "START ---------------------------------------------------------------------------> "
#pause

#echo "CPU Inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_cpu_inventory.yml 
#echo "CPU Inventory - work"
#pause

#echo "Get disk inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_disk_inventory.yml
#echo "Get disk inventory - work"
#pause

#echo "Fan Inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_fan_inventory.yml
#echo "Fan Inventory - work"
#pause

#echo "Get Firmware Inventory - not work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_firmware_inventory.yml

#echo "Get Firmware Update Capabilities - not work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_firmware_update_methods.yml

#echo "Get memory inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_memory_inventory.yml
#echo "Get memory inventory - work"
#pause

#echo "Get NIC Information - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_nic_inventory.yml
#echo "Get NIC Information - work"
#pause

#echo "Get PSU Inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_psu_inventory.yml
#echo "Get PSU Inventory - work"
#pause

#echo "Get sessions - not work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_session_information.yml

#echo "Get storage controller inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_storage_cont_inventory.yml
#echo "Get storage controller inventory - work"
#pause
#echo "Get BIOS Attributes - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_bios.yml
#echo "Get BIOS Attributes - work"

echo "Get xml - work"
ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_xml.yml
echo "Get xml - work"

#echo "Get Inventory all - work"
#ansible-playbook -i example_inventory.yml ./roles/inventory/tasks/get_system_inventory_all.yml
#echo "Get Inventory all - work"

#echo "Get Inventory default - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_system_inventory_default.yml
#pause

#echo "Get Inventory system - work "
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_system_inventory_several.yml
#echo "Get Inventory default - work"
#pause

#echo "Getting system inventory - work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_system_inventory.yml
#echo "Getting system inventory - work"
#pause

#echo "Get Virtual Media information - not work" 
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_virtual_media.yml

#echo "Get Volume Inventory - not work"
#ansible-playbook -i inventory.yml ./roles/inventory/tasks/get_volume_inventory.yml
echo "END"
echo "Run run_parser.sh"
pause
./run_parser.sh
