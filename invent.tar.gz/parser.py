#!/usr/bin/env python3

import json
import yaml
from collections import OrderedDict
from os import listdir
from os import path
import xml.etree.ElementTree as ET
import re

def get_json_data(datafile):
    '''parsing from JSON input files (e.g. lshw, nvme) into JSON output'''
    data = json.load(datafile)
    path = ''
    pathlist = []
    meta_count = 0
    meta_islist = None
    meta_count_dest = None
    meta_list = ''
    meta_file = metadata[meta][0].split(';')[0]
    meta_path = metadata[meta][1].split(';')[0]
    meta_object = metadata[meta][1].split(';')[1]
    meta_dest = metadata[meta][2]
    if len(metadata[meta][0].split(';')) > 1:
        meta_islist = True
        meta_list = metadata[meta][1].split(';')[2]
    else:
        meta_islist = False
    if len(metadata[meta]) > 3:
        meta_count_dest = metadata[meta][3]
    if meta_file == 'nvme.json':
        pathlist.append('[\'Devices\']')
    elif meta_file == 'lshw.json':
        trigger = True
        while trigger:
            for i, pathpart in enumerate(meta_path.split('/')):
                for j, child in enumerate(eval('data' + path + '[\'children\']')):
                    if pathpart in eval('data' + path + '[\'children\']' + '[' + str(j) + '][\'id\']'):
                        if path + '[\'children\']' + '[' + str(j) + ']' not in pathlist:
                            if i + 1 == len(meta_path.split('/')):
                                if meta_islist == True:
                                    path = path + '[\'children\']' + '[' + str(j) + ']'
                                    pathlist.append(path)
                                    path = ''
                                    break
                                else:
                                    path = path + '[\'children\']' + '[' + str(j) + ']'
                                    trigger = False
                                    break                            
                            else:
                                if path + '[\'children\']' + '[' + str(j) + ']' not in pathlist:
                                    path = path + '[\'children\']' + '[' + str(j) + ']'
                                    break
                else:
                    if i + 1 == len(meta_path.split('/')):
                        trigger = False
                    else:
                        path = ''
    to_pull = ''
    childfix = ''
    if meta_file == 'lshw.json':
        childfix = '[\'children\']'    
    if meta_islist == True:
        for pathlist_element in pathlist:
            try:
                for j, child in enumerate(eval('data' + pathlist_element + childfix)):
                    if (meta_object == '' or meta_object in eval('data' + pathlist_element + childfix + '[' + str(j) + '][\'id\']')):
                        for item in meta_list.split(','):
                            if '/' in item:
                                item_construct = item.split('/')[0] + '\'][\'' + item.split('/')[1]
                                item_name = item.split('/')[1]
                            else:
                                item_construct = item
                                item_name = item
                            try:
                                if eval('data' + pathlist_element + childfix + '[' + str(j) + '][\'' + item_construct + '\']') == 'NO DIMM':
                                    break
                                to_pull = to_pull + '\'' + item_name + '\':\'' + str(eval('data' + pathlist_element + childfix + '[' + str(j) + '][\'' + item_construct + '\']')).replace(',','') + '\','
                            except KeyError:
                                pass
                        if to_pull != '':
                            exec('output' + meta_dest + '.append({' + str(to_pull[:-1]) + '})')
                            to_pull = ''
                            if meta_count_dest is not None:
                                meta_count += 1
            except IndexError:
                pass
            except KeyError:
                pass
        if meta_count_dest is not None:
            exec('output' + meta_count_dest + '=\'' + str(meta_count) + '\'')
    else:
        exec('output' + meta_dest + '=data' + path + '[\'' + meta_object + '\']')

def get_xml_data(datafile):
    '''parsing from iDRAC XML output files'''
    to_pull = ''
    the_value = ''
    meta_islist = None
    meta_objects = ''
    meta_count_dest = None
    meta_count = 0
    meta_file = metadata[meta][0].split(';')[0]
    meta_class = metadata[meta][1].split(';')[0]
    meta_key = metadata[meta][1].split(';')[1]
    meta_dest = metadata[meta][2]
    if len(metadata[meta][0].split(';')) > 1:
        meta_islist = True
        meta_objects = metadata[meta][1].split(';')[2]
    else:
        meta_islist = False
        meta_objects = metadata[meta][1].split(';')[2]
    if len(metadata[meta]) > 3:
        meta_count_dest = metadata[meta][3]
    data = ET.parse(datafile).getroot()
    for i, child in enumerate(data.findall('Component')):
        if (meta_key in child.attrib['Key'] and child.attrib['Classname'] == meta_class):
            for property in child.findall('PROPERTY'):
                if property.attrib['NAME'] in meta_objects:
                    if property[0].text is not None:
                        if meta_islist == True:
                            if (meta_key == 'NIC' and property.attrib['NAME'] == 'ProductName'):
                                if re.compile('([a-fA-F0-9]{2}[:|\-]?){6}').search(property[1].text):
                                    the_value = property[1].text[:-20]
                                else:
                                    the_value = property[1].text
                            else:
                                the_value = property[1].text
                            to_pull = to_pull + '\'' + property.attrib['NAME'] + '\':\'' + the_value + '\','
                        else:
                            try:
                                if property[1].text[:9] == 'PowerEdge':
                                    exec('output' + '[\'type\']' + '=\'' + property[1].text.split(' ')[0] + '\'')
                                    exec('output' + meta_dest + '=\'' + property[1].text.split(' ')[1] + '\'')
                                else: 
                                    exec('output' + meta_dest + '=\'' + property[1].text + '\'')
                            except IndexError:
                                pass
                            except KeyError:
                                pass
            if meta_islist == True:
                try:
                    exec('output' + meta_dest + '.append({' + str(to_pull[:-1]) + '})')
                    if meta_count_dest is not None:
                        meta_count += 1
                except IndexError:
                    pass
                except KeyError:
                    pass
    if meta_count_dest is not None:
        exec('output' + meta_count_dest + '=\'' + str(meta_count) + '\'')

def get_txt_data(datafile):
    meta_objectcount = 0
    meta_object = metadata[meta][1]
    meta_dest = metadata[meta][2]
    if len(metadata[meta][0].split(';')) > 1:
        meta_islist = True
        meta_objectcount = int(metadata[meta][0].split(';')[2])
    else:
        meta_islist = False
    if meta_file[-7:] == "fru.txt":
        if meta_islist == True:
            k = 0
            to_pull = ''
            for line in datafile:
                try:
                    key, value = line.strip().replace(',','').split(':',1)
                except ValueError:
                    value = ''
                if meta_object in value:
                    k = meta_objectcount
                    to_pull = ''
                if k > 0:
                    to_pull = to_pull + '\'' + key.strip() + '\':\'' + value.strip() + '\','
                    k -= 1
                    if k == 0:
                        exec('output' + meta_dest + '.append({' + str(to_pull[:-1]) + '})')
        else:
            for line in datafile:
                try:
                    key, value = line.strip().split(':',1)
                    key = key.replace(' ', '')
                except ValueError:
                    pass
                if meta_object == key:
                    exec('output' + meta_dest + ' = value.strip()')
                    break
    else:
        for line in datafile:
            key, value = line.strip().split(':',1)
            key = key.replace(' ', '')
            if meta_object == key:
                exec('output' + meta_dest + ' = value.strip()')
                break

def remove_data(output, removefile):
    '''removes data from JSON output'''
    for meta in removefile:
        for element in removefile[meta][1].split(';'):
            for i, item in enumerate(eval('output' + removefile[meta][0])):
                try:
                    exec('del output' + removefile[meta][0] + '[' + str(i) + ']' + element)
                except KeyError:
                    pass
    return output

def groupby(jsonoutput, dataname, ignore_list):
    '''function that adds parameter to JSON elements that sort duplicates'''
    for element in jsonoutput[dataname]:
        element['parameter'] = 0
    ignore_list.append('parameter')
    unique_count = 1
    for i, element in enumerate(jsonoutput[dataname]):
        no_match = False
        if i > 0:
            n = 0
            while n <= i - 1:
                for subelement in element:
                    if subelement not in ignore_list:
                        if jsonoutput[dataname][i][subelement] != jsonoutput[dataname][n][subelement]:
                            no_match = True
                if no_match is False:
                    element['parameter'] = jsonoutput[dataname][n]['parameter']
                    break
                else:
                    element['parameter'] = unique_count
                no_match = False
                n += 1
            else:
                unique_count += 1
        else:
            element['parameter'] = 1
            unique_count += 1

def groupnics(jsonoutput, name_name, mac_name, slot_name, fw_name, delimiter):
    '''function to reorganize information about NICs, that needs special grouping'''
    niccount = []
    macs = []
    for element in jsonoutput['nics']:
        element[slot_name] = element[slot_name].split(delimiter)[0]
    groupby(jsonoutput, 'nics', [mac_name, name_name, fw_name])
    for element in jsonoutput['nics']:
        niccount.append(element['parameter'])
    niccount = list(dict.fromkeys(niccount))
    for each in niccount:
        macs = []
        for element in jsonoutput['nics']:
            if element['parameter'] == each:
                try:
                    macs.append(element[mac_name])
                except KeyError:
                    pass
        for element in jsonoutput['nics']:
            if (element['parameter'] == each and len(macs) > 0):
                j = 1
                while j <= len(macs):
                    element['MAC' + str(j)] = macs[j-1]
                    j += 1

def passtocsv(csvfile, jsonoutput, csvmapfile):
    '''function to parse from JSON output file into CSV output'''
    with open(csvmapfile, 'r') as csvmap:
        lines = csvmap.readlines()
        last = lines[-1]
        line_notempty = None
        line_type = ''
        line_addr = ''
        line_value = ''
        for line in lines:
            if len(line.split(';')) > 1:
                line_notempty = True
                line_type = line.split(';')[1]
                line_addr = line.split(';')[2]
                if len(line.split(';')) > 3:
                    line_value = line.split(';')[3]
            else:
                line_notempty = False
            if line_notempty == True:
                if line_type == '1to1':
                    try:
                        csvfile.write(eval('jsonoutput' + line_addr) + ',')
                    except IndexError:
                        csvfile.write(',')
                else:
                    counter = 0
                    if line_value[:-1] == 'count':
                        for element in jsonoutput[line_type]:
                            if str(element['parameter']) == line_addr:
                               counter += 1
                        if counter > 0:
                            csvfile.write(str(counter) + ',')
                        else:
                            csvfile.write(',')
                    else:
                        if len(jsonoutput[line_type]) == 0:
                            csvfile.write(',')
                        for i, element in enumerate(jsonoutput[line_type]):
                            if str(element['parameter']) == line_addr:
                                try:
                                    csvfile.write(str(element[line_value[:-1]]) + ',')
                                    break
                                except KeyError:
                                    csvfile.write(',')
                                    break
                            elif i + 1 == len(jsonoutput[line_type]):
                                csvfile.write(',')
            else:
                if line is not last:
                    csvfile.write(',')
                else:
                    csvfile.write('\n')

def labelcsv(mapfile, csvfilename):
    '''method to generate first line with labels for CSV outputs'''
    with open(csvfilename, 'w') as csvfile:
        with open(mapfile, 'r') as csvmap:
            lines = csvmap.readlines()
            last = lines[-1]
            for line in lines:
                if line is not last:
                    csvfile.write(line.split(';')[0][:-1] + ',')
                else:
                    csvfile.write(line.split(';')[0][:-1] + '\n')

#Loading data, configuration                      
with open('configparse.yaml') as yamlfile:
    metadata = yaml.load(yamlfile, Loader=yaml.FullLoader)
labelcsv('csvmap_dell', 'output_csv/dell.csv')
labelcsv('csvmap_intel', 'output_csv/intel.csv')
#Generating JSON output
for directory in sorted(listdir('inventory_files')):    
    with open('example.json') as example:    
        output = json.load(example, object_pairs_hook=OrderedDict)
    print('Generating JSON output for ' + str(directory))
    for meta in metadata:            
        meta_file = metadata[meta][0].split(';')[0] 
        file_path = 'inventory_files/' + directory + '/' + directory + '_' + meta_file
        if path.exists(file_path) and path.getsize(file_path) > 0:
            with open(file_path) as datafile:
                if meta_file.endswith('xml'):
                    get_xml_data(datafile)
                elif meta_file.endswith('txt'):
                    get_txt_data(datafile)
                elif meta_file.endswith('json'):
                    get_json_data(datafile)
                else:
                    print(meta_file + ': Critical error. Wrong format!')
#Removing JSON elements from output if necessary
    with open('configremove.yaml') as yamlremove:
        removefile = yaml.load(yamlremove, Loader = yaml.FullLoader)
        if removefile is not None:
            output = remove_data(output, removefile)            
#Writing JSON output
    with open('output_json/' + directory + '.json', 'w') as outfile:  
        json.dump(output, outfile)
#Generating CSV output
for filename in listdir('output_json'):
    print('Parsing ' + str(filename) + ' into CSV output')
    with open('output_json/' + filename, 'r') as outputfile:
        jsonoutput = json.load(outputfile)
        if jsonoutput['manufacturer'] == 'Intel Corporation':
            #Parse to CSV (Intel)
            groupby(jsonoutput, 'memory', ['slot'])
            groupby(jsonoutput, 'disks', ['businfo', 'description', 'handle'])
            groupby(jsonoutput, 'PCIe', ['DevicePath'])
            groupby(jsonoutput, 'PSUs', [])
            groupby(jsonoutput, 'cpus', [])
            groupnics(jsonoutput, 'product', 'serial', 'businfo', 'firmware', '.')
            groupby(jsonoutput, 'disk_controllers_integrated', []) 
            with open('output_csv/intel.csv', 'a') as csvfile:
                passtocsv(csvfile, jsonoutput, 'csvmap_intel')
        else:
            #Parse to CSV (Dell)
            groupby(jsonoutput, 'memory', [])
            groupby(jsonoutput, 'disks', [])
            groupby(jsonoutput, 'PCIe', ['SlotType','Manufacturer','FQDD'])
            groupby(jsonoutput, 'PSUs', [])
            groupby(jsonoutput, 'cpus', [])
            groupnics(jsonoutput, 'ProductName', 'PermanentMACAddress', 'FQDD', 'FamilyVersion', '-')
            groupby(jsonoutput, 'disk_controllers_external', [])
            groupby(jsonoutput, 'disk_controllers_integrated', [])
            with open('output_csv/dell.csv', 'a') as csvfile:
                passtocsv(csvfile, jsonoutput, 'csvmap_dell')
        
